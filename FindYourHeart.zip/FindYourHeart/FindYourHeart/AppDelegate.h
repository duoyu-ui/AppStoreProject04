//
//  AppDelegate.h
//  FindYourHeart
//
//  Created by Earth on 2020/9/30.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

